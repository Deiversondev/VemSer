function Login() {
  return (
    <div>
      <button>Ativar</button>
    </div>
  )
}

export default Login;